Ext.define('ManageCustomer.controller.Main', {
    extend: 'Ext.app.Controller',    
    views: ['CustomerId','CustomerEdit','Order','OrderProduct','Viewport'],
    refs:[
          {ref:'viewport',selector:'customerviewport'},
          {ref:'customerId',selector:'customerid'},
          {ref:'customerEdit',selector:'customeredit'},         
          {ref:'order',selector:'order'},
          {ref:'orderproduct',selector:'orderproduct'}
         ],
         
	init: function() {       
		this.control({		
            'button[text=Go]':{click:this.loadCustomer},
            'button[text=Submit]': {click: this.submitCustomer},
            'button[text=Back]': {click: this.back},
          
            '#orders>panel>button[text=Place new order]':{click:this.addOrder},            
            '#orders>panel>button[text=Remove]':{click:this.removeOrder},
            
            'reflectcollection[path=productsCollection]>panel>button[text=Order new product]':{click:this.addOrderProduct},            
            'reflectcollection[path=productsCollection]>panel>button[text=Remove]':{click:this.removeOrderProduct}

        });
    },
	
	loadCustomer:function(){
    	var custForm=this.getCustomerEdit().down('reflectpanel');
    	custForm.reset();
    	custForm.paramsForLoad.customerId=this.getCustomerId().down('textfield[name=customerId]').getValue();
    	custForm.paramsForLoad.password=this.getCustomerId().down('textfield[name=password]').getValue();
    	custForm.urlForLoad="/ExtPOC/ajax/loadCustomer";
    	try{
    		custForm.load({ 
    			waitMsg:'Loading...',
    			scope:this,
    			success:function(){this.getViewport().getLayout().next();}
    		});		
    	}catch(e){
    		Ext.msg.alert('Error','Loading failed due to unexpected exception!');
    	}
	},
		
	submitCustomer:function(){
    	this.getCustomerEdit().down('reflectpanel').urlForSubmit="/ExtPOC/ajax/updateCustomer";
		this.getCustomerEdit().down('reflectpanel').submit({
			waitMsg:'Submitting...',
			scope:this,
			success:function(){Ext.Msg.alert('Submit succeed!');this.back();},
			failure:function(){Ext.Msg.alert('Submit failed');}			
		});
	},
	
	back:function(){
		this.getViewport().getLayout().prev();	
	},
	
	removeOrder:function(b,e){
		var a=b.up('#orders');
		var selections=a.getSelections();
		for(var i=0;i<selections.length;i++){
			selections[i].urlForSubmit="/ExtPOC/ajax/removeOrder";
			selections[i].submit({
				waitMsg:'Submitting...',
				scope:this,
				success:function(){},
				failure:function(){Ext.Msg.alert('Submit failed');}			
			});
			a.removeItem(selections[i]);
		}
	},
	
	addOrder:function(b,e){
		var order=Ext.create('ManageCustomer.view.Order',{modal:true});
		order.child('reflectpanel').paramsForSubmit.customerId=this.getCustomerId().down('textfield[name=customerId]').getValue();
		order.child('reflectpanel').urlForSubmit="/ExtPOC/ajax/placeOrder";
        order.down('button[text=Ok]').on('click',this.submitOrder);            
        order.down('button[text=Cancel]').on('click',this.cancelOrder);
		order.show();
	},
	
	submitOrder:function(b,e){
		b.up('order').child('reflectpanel').submit({
			waitMsg:'Submitting...',
			scope:this,
			success:function(){
				Ext.ComponentQuery.query('#orders')[0].addItem(b.up('order').child('reflectpanel').submitResponseData);
				b.up('order').close();
			},
			failure:function(){Ext.Msg.alert('Submit failed');}			
		});
	},
	
	cancelOrder:function(b,e){
		b.up('order').close();	
	},
	
	removeOrderProduct:function(b,e){
		var a=b.up('reflectcollection[path=productsCollection]');
		var selections=a.getSelections();
		for(var i=0;i<selections.length;i++){
			selections[i].urlForSubmit="/ExtPOC/ajax/removeOrderProduct";
			selections[i].submit({
				waitMsg:'Submitting...',
				scope:this,
				success:function(){},
				failure:function(){Ext.Msg.alert('Submit failed');}			
			});
			a.removeItem(selections[i]);
		}
	},
	
	addOrderProduct:function(b,e){
		var orderproduct=Ext.create('ManageCustomer.view.OrderProduct',{modal:true});
		orderproduct.order=b.up('reflectcollection').up('reflectpanel');
		orderproduct.child('reflectpanel').paramsForSubmit.orderId=orderproduct.order.down('textfield[name=orderId]').getValue();
		orderproduct.child('reflectpanel').urlForSubmit="/ExtPOC/ajax/addOrderProduct";
		orderproduct.down('button[text=Ok]').on('click',this.submitOrderProduct);            
		orderproduct.down('button[text=Cancel]').on('click',this.cancelOrderProduct);
		orderproduct.show();
	},
	
	submitOrderProduct:function(b,e){
		b.up('orderproduct').child('reflectpanel').paramsForSubmit.productId=b.up('orderproduct').child('reflectpanel').down('textfield[name=productId]').getValue();
		b.up('orderproduct').child('reflectpanel').submit({
			waitMsg:'Submitting...',
			scope:this,
			success:function(){
				b.up('orderproduct').order.down('reflectcollection').addItem(b.up('orderproduct').child('reflectpanel').submitResponseData);
				b.up('orderproduct').close();
			},
			failure:function(){Ext.Msg.alert('Submit failed');}			
		});
	},
	
	cancelOrderProduct:function(b,e){
		b.up('orderproduct').close();	
	}		
});