Ext.Loader.setConfig({enabled: true});	// turn on dynamic loading
Ext.Loader.setPath('Ext', "ext/src");

Ext.require(
		[
		 	'Ext.ux.reflective.Panel',
		 	'Ext.ux.reflective.GridPanel',
		 	'Ext.ux.reflective.Collection'	]
	);

Ext.application({
    name: 'ManageCustomer',
    controllers: ["Main"],
    launch:function(){
        var Mainview = Ext.create('ManageCustomer.view.Viewport', {
        	renderTo:Ext.get('Main')
        });
	}
});
