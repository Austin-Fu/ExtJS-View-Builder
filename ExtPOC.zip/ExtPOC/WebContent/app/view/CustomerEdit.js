Ext.define('ManageCustomer.view.CustomerEdit', {
	alias : "widget.customeredit",
	items : [ {
		title : "Customer Profile",
		root : "Customer",
		items : [ {
			items : [ {
				name : "customerId",
				xtype : "textfield",
				fieldLabel : "customerId"
			}, {
				name : "firstName",
				xtype : "textfield",
				fieldLabel : "firstName"
			}, {
				name : "lastName",
				xtype : "textfield",
				fieldLabel : "lastName"
			}, {
				name : "homePhone",
				xtype : "textfield",
				fieldLabel : "homePhone"
			}, {
				name : "cellPhone",
				xtype : "textfield",
				fieldLabel : "cellPhone"
			}, {
				name : "addr1",
				xtype : "textfield",
				fieldLabel : "addr1"
			}, {
				name : "addr2",
				xtype : "textfield",
				fieldLabel : "addr2"
			}, {
				name : "city",
				xtype : "textfield",
				fieldLabel : "city"
			}, {
				name : "postalCode",
				xtype : "textfield",
				fieldLabel : "postalCode"
			}, {
				name : "email",
				xtype : "textfield",
				fieldLabel : "email"
			}, {
				name : "password",
				xtype : "textfield",
				fieldLabel : "password"
			} ],
			layout : {
				columns : 2,
				type : "table"
			},
			xtype : "panel",
			padding : 10
		}, {
			id : "orders",
			autoPaging:false,
			itemsPerPage:2,	// only applicable when autoPaging true
			items : [ {
				xtype : 'panel',
				items : [ {
					text : "Place new order",
					xtype : "button"
				}, {
					text : "Remove",
					xtype : "button"
				} ]
			} ],
			template : {
				root : "Customer",
				collapsible : true,
				items : [ {
					items : [ {
						name : "orderId",
						xtype : "textfield",
						fieldLabel : "orderId"
					}, {
						name : "placedDate",
						xtype : "textfield",
						fieldLabel : "placedDate"
					}, {
						name : "price",
						xtype : "textfield",
						fieldLabel : "price"
					}, {
						name : "status",
						xtype : "textfield",
						fieldLabel : "status"
					}, {
						name : "comments",
						xtype : "textfield",
						fieldLabel : "comments"
					} ],
					layout : {
						columns : 2,
						type : "table"
					},
					xtype : "panel",
					padding : 10
				}, {
					template : {
						root : "Customer",
						collapsible : true,
						items : [ {
							items : [ {
								name : "orderProductId",
								xtype : "textfield",
								fieldLabel : "orderProductId"
							},{
								name : "quantity",
								xtype : "textfield",
								fieldLabel : "quantity"
							}, {
								name : "comments",
								xtype : "textfield",
								fieldLabel : "comments"
							} ],
							layout : {
								columns : 2,
								type : "table"
							},
							xtype : "panel",
							padding : 10
						}, {
							title : "Product details",
							root : "Customer",
							items : [ {
								items : [ {
									name : "productId",
									xtype : "textfield",
									fieldLabel : "productId"
								}, {
									name : "name",
									xtype : "textfield",
									fieldLabel : "name"
								}, {
									name : "price",
									xtype : "textfield",
									fieldLabel : "price"
								}, {
									name : "supplier",
									xtype : "textfield",
									fieldLabel : "supplier"
								} ],
								layout : {
									columns : 2,
									type : "table"
								},
								xtype : "panel",
								padding : 10
							} ],
							xtype : "reflectpanel",
							path : "product",
							padding : 10
						} ],
						xtype : "reflectpanel"
					},
					title : "Products",
					root : "Customer",
					xtype : "reflectcollection",
					path : "productsCollection",
					padding : 10,
					items : [ {
						xtype : 'panel',
						items : [ {
							text : "Order new product",
							xtype : "button"
						}, {
							text : "Remove",
							xtype : "button"
						} ]
					} ]
				} ],
				xtype : "reflectpanel"
			},
			title : "Orders",
			root : "Customer",
			collapsible : true,
			xtype : "reflectcollection",
			path : "ordersCollection",
			padding : 10
		} ],
		xtype : "reflectpanel",
		padding : 10
	}, {
		items : [ {
			text : "Submit",
			xtype : "button"
		}, {
			text : "Back",
			xtype : "button"
		} ],
		layout : {
			columns : 2,
			type : "table"
		},
		xtype : "panel"
	} ],
	extend : "Ext.panel.Panel"
});