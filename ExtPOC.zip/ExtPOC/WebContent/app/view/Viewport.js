Ext.define('ManageCustomer.view.Viewport', {
    extend: 'Ext.Panel',
    alias:'widget.customerviewport',
    layout: 'card',
    items: [
	{xtype: 'customerid'},
	{xtype: 'customeredit'}
	]
});