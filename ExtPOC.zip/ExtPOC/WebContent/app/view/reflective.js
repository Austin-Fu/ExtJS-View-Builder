/**
 * @author Austin Fu
 * @name reflectiveComp
 *
 * @description
 * Implements a UI/view reflective to back-end data model, which typically can be a Java Object.
 *
* # CSS classes
 *  - rf-panel: 
 *  - rf-heading: 
 *  - rf-add
  *   
 * @example
    <example module="reflectiveExample">
    </example>
 *
 */

function ReflectiveController($http,$scope){
	
	this.load = function(cfg) {
		var ctrl=this;

		var config;
		if (cfg)
			config = cfg;
		else
			config = {};
		config.method = 'POST';
		if (!config.url)
			config.url = ctrl.urlForLoad;
		if (!config.params)
			config.params = ctrl.paramsForLoad;
		if (!config.errorAlert)
			config.errorAlert = ctrl.errorAlert;

		var responsePromise = $http(config);

		responsePromise.success(function(data, status,
				headers, config) {
			ctrl[ctrl.root] = data;
		});

		responsePromise.error(function(data, status,
				headers, config) {
			if(config.errorAlert && alert)
				alert(config.errorAlert);
			if(console.error)
				console.error(config.url+" failed with status:"+status);
		});
	};

	this.submit = function(cfg) {
		var ctrl=this;

		var config ;
		if(cfg)
			config=cfg;
		else 
			config = {};
			config.method = 'POST';
		if(!config.url)
			config.url = ctrl.urlForSubmit;
		if(!config.params)
			config.params = ctrl.paramsForSubmit;
		if (!config.errorAlert)
			config.errorAlert = ctrl.errorAlert;

		var responsePromise = $http(config);

		responsePromise.success(function(data, status,
				headers, config) {
			ctrl.$submitResp=data;
		});

		responsePromise.error(function(data, status,
				headers, config) {
			if(config.errorAlert && alert)
				alert(config.errorAlert);
			if(console.error)
				console.error(config.url+" failed with status:"+status);
		});
	};	
	
}

var reflectiveComp={
				bindings : {
					/**
					 * @cfg {String} root
					 */
					root : '@',
					/**
					 * @cfg {String} urlForLoad
					 */
					urlForLoad: '@',
					/**
					 * @cfg {Object} paramsForLoad
					 */
					paramsForLoad : '<',
					/**
					 * @cfg {String} urlForSubmit
					 */
					urlForSubmit : '@',
					/**
					 * @cfg {Object} paramsForSubmit
					 */
					paramsForSubmit : '<',
					/**
					 * @cfg {Object} errorAlert
					 */
					errorAlert : '@',
					/**
					 * @cfg {Boolean} loadOnExpand If true, loading will be
					 *      triggered by first-time expanding.
					 */
					loadOnExpand : '@',
				},
				controller : ['$http','$scope',ReflectiveController],
};
