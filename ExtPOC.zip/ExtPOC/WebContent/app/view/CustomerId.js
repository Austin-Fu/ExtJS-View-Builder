Ext.define('ManageCustomer.view.CustomerId', {
	title : "Customer LogIn",
	alias : "widget.customerid",
	items : [{
		name : "customerId",
		xtype : "textfield",
		fieldLabel : "Customer ID"
	}, {
		inputType : "password",
		name : "password",
		xtype : "textfield",
		fieldLabel : "Password"
	}, {
		text : "Go",
		xtype : "button"
	}],
	extend : "Ext.panel.Panel",
	layout : {
		columns : 1,
		type : "table"
	}
});