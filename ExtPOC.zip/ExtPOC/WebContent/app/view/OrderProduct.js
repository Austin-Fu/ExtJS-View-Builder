Ext.define('ManageCustomer.view.OrderProduct',{
	alias : "widget.orderproduct",
	title : "New Order Product",
	items : [{
		root : "OrderProduct",
		items : [{
			items : [{
				name : "orderProductId",
				xtype : "textfield",
				fieldLabel : "orderProductId"
			}, {
				name : "productId",
				xtype : "textfield",
				fieldLabel : "productId"
			}, {
				name : "quantity",
				xtype : "textfield",
				fieldLabel : "quantity"
			}, {
				name : "comments",
				xtype : "textfield",
				fieldLabel : "comments"
			}],
			layout : {
				columns : 2,
				type : "table"
			},
			xtype : "panel",
			padding : 5
		}],
		xtype : "reflectpanel"
	}, {
		items : [{
			text : "Ok",
			xtype : "button"
		}, {
			text : "Cancel",
			xtype : "button"
		}],
		layout : {
			columns : 2,
			type : "table"
		},
		xtype : "panel"
	}],
	extend : "Ext.window.Window"
});