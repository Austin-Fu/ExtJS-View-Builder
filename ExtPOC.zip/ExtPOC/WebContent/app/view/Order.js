Ext.define('ManageCustomer.view.Order',{
	title : "New Order",
	alias : "widget.order",
	items : [{
		root : "Order",
		collapsible : true,
		items : [{
			items : [{
				name : "orderId",
				xtype : "textfield",
				fieldLabel : "orderId"
			}, {
				name : "placedDate",
				xtype : "textfield",
				fieldLabel : "placedDate"
			}, {
				name : "price",
				xtype : "textfield",
				fieldLabel : "price"
			}, {
				name : "status",
				xtype : "textfield",
				fieldLabel : "status"
			}, {
				name : "comments",
				xtype : "textfield",
				fieldLabel : "comments"
			}],
			layout : {
				columns : 2,
				type : "table"
			},
			xtype : "panel",
			padding : 10
		}],
		xtype : "reflectpanel"
	}, {
		items : [{
			text : "Ok",
			xtype : "button"
		}, {
			text : "Cancel",
			xtype : "button"
		}],
		layout : {
			columns : 2,
			type : "table"
		},
		xtype : "panel"
	}],
	extend : "Ext.window.Window",
	layout : {
		type : "auto"
	}
});