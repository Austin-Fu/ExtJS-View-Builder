/**
 * @docauthor Austin Fu 
 * 
 * Collection of "Reflective" components
 
 */
Ext.define('Ext.ux.reflective.Collection', {
    extend:'Ext.ux.reflective.Panel',
    alias: 'widget.reflectcollection',
    alternateClassName: ['ReflectCollection'],
    
    /**
    *@cfg
    */
    template:{},	// one and only one used as template for populating items
    autoPaging:false,
    itemsPerPage:0,	// only applicable when autoPaging true
    
    getItemsPanel:function(){
    	return this.child('[name=itemsPanel]');
    },
    
    newItemsPanel:function(){
    	var itemsPanel=null;
    	if(this.autoPaging)
    	{
    		itemsPanel=Ext.create('Ext.tab.Panel',{name:'items'});
    		itemsPanel.setLayout(Ext.create('Ext.layout.container.Card'));
    		this.setLayout(Ext.create('Ext.layout.container.Fit'));
    	}
    	else
    		itemsPanel=Ext.create('Ext.panel.Panel');
    	itemsPanel.name='itemsPanel';
		return itemsPanel; 	
    },
    
    newItem:function(itemsPanel,i){
    	var num=this.itemsPerPage>0?this.itemsPerPage:this.loadedData.length;
		var tab=null;
		var config={header:{items:[{xtype:'checkbox',submitValue:false}]}};
		Ext.apply(config,this.template);
		if(!this.template.title)
			config.title=this.title+" item# "+(i+1).toString();
		var item=Ext.create('Ext.ux.reflective.Panel',config);
		this.buildItem(item,this.loadedData,i);
		if(this.autoPaging)
		{
			if(i%num==0)
			{
				tab=Ext.create('Ext.panel.Panel',{title:Math.floor(i/num)+1});
				itemsPanel.add(tab);
			}
			if(tab)
				tab.add(item);
		}
		else
			itemsPanel.add(item);    	
    },
    
    buildFrom:function(data)
    {
		this.loadedData=this.translateForLoad(data);

		if(Array.isArray==undefined){	// IE 8 doesn't support Array.isArray	
			Array.isArray = function (obj) {
				return Object.prototype.toString.call(obj) === "[object Array]";
			};
		}		
		if(!Array.isArray(this.loadedData)||!this.template)
    		return;    	
		
    	this.suspendLayout=true;
    	if(this.loaded)	// remove items populated by last load
    		this.reset();
    	var itemsPanel=this.newItemsPanel();
    	this.add(itemsPanel);    		
    	for(var i=0;i<this.loadedData.length;i++)
    		this.newItem(itemsPanel, i);
		this.loaded=true;
		this.suspendLayout=false;		
		this.doLayout();
    },
    
    addItem:function(data){
    	this.suspendLayout=true;
    	if(!this.loaded)
    		return;

    	var itemsPanel=this.getItemsPanel();
    	if(itemsPanel==null){
    		itemsPanel=this.newItemsPanel();
    		this.add(itemsPanel);
    	}
    	
    	this.loadedData.push(data);    		
    	this.newItem(itemsPanel, this.loadedData.length-1);
		this.suspendLayout=false;		
		this.doLayout();    	
    },
    
    
    
    /**
     * Get data for submit
     */
    getSubmitData:function(){
		var data=[];
		var reflectives=this.getChildReflectives();
		for(var i=0;i<reflectives.length;i++)
			data.push(reflectives[i].getSubmitData());
		return this.translateForSubmit(data);
    },
    
    reset:function(){
		var populated=this.getItemsPanel();
		if(populated)		
			this.remove(populated);
		if(this.loadOnExpand)
			this.collapse();
	},
	
	getSelections:function(){
		var selections=[];
		var reflectives=this.getChildReflectives();
		for(var i=0;i<reflectives.length;i++)
			if(reflectives[i].down('header checkbox').checked)
				selections.push(reflectives[i]);	
		return selections;
	},
	
	removeSelections:function(){
		var itemsPanel=this.getItemsPanel();
		if(itemsPanel){
			for(var i=0;i<this.getSelections().length;i++)
				if(this.autoPaging){
					for(var j=0;j<itemsPanel.items.length;j++)
						itemsPanel.items.getAt(j).remove(selections[i]);
				}
				else
					itemsPanel.remove(selections[i]);
		}
	},
	
	removeItem:function(item){
		var itemsPanel=this.getItemsPanel();
		if(itemsPanel){
			if(this.autoPaging){
				for(var j=0;j<itemsPanel.items.length;j++)
					itemsPanel.items.getAt(j).remove(item);
			}
			else
				itemsPanel.remove(item);
		}
	}
});
