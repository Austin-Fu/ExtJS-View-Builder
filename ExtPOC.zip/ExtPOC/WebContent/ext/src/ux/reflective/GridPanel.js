/**
 * @docauthor Austin Fu 
 * 
 * This GridPanel is intended for rendering list/collection as a grid 
 */

Ext.define('Ext.ux.reflective.GridPanel', {
    extend:'Ext.grid.Panel',
    alias: 'widget.reflectgrid',
    alternateClassName: ['ReflectGrid'],
    mixins:['Ext.ux.reflective.Collection'],
        
    buildFrom:function(data){
		this.loadedData=this.translateForLoad(data);
		if(!this.loadedData||!Array.isArray(this.loadedData))
			return;

		var fields=[];
		if(this.loadedData.length>0)
			for(var name in this.loadedData[0])
				fields.push({name:name});
		var pageSize=this.loadedData.length;
		if(this.autoPaging&&this.itemsPerPage>0)
			pageSize=this.itemsPerPage;
		var store=Ext.create('Ext.data.Store',{
			fields:fields,
			data:this.loadedData,
			pageSize:pageSize,
			proxy:Ext.create('Ext.ux.reflective.PagingMemoryProxy')});
		this.reconfigure(store);
		if(this.autoPaging){
			this.pagingToolbar=Ext.create('Ext.PagingToolbar',{store:store});
			this.addDocked(this.pagingToolbar);
		}

		this.loaded=true;
    },

    /**
     * Get data for submit
     */
    getSubmitData:function(){
		var data=[], pageSize=this.store.getTotalCount();
		if(this.autoPaging && this.itemsPerPage>0)
			pageSize=this.itemsPerPage;
		for(var i=0;i<this.store.getTotalCount();i++){
			if(i%pageSize==0){	
				this.store.loadPage(Math.floor(i/pageSize)+1);	// load next page
			}			
			data.push(this.store.getAt(i%pageSize).data);
		}
    	return this.translateForSubmit(data);
    },
    
    reset:function(){
    	if(this.pagingToolbar)
    		this.remove(this.pagingToolbar);
		if(this.loadOnExpand)
			this.collapse();
    }
});
