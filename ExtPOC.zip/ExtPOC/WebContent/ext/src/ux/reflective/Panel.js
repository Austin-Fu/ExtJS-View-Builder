/**
 * @docauthor Austin Fu 
 * 
 * Reflective panel provides a "reflective" view for back-end data model, which typically can be a Java Object.
 * 
 */

Ext.define('Ext.ux.reflective.Panel', {
    extend:'Ext.panel.Panel',
    alias: 'widget.reflectpanel',
    alternateClassName: ['ReflectPanel'],
    
    /**
     * @cfg {String} root
     */
    root:'',    
    /**
     * @cfg {String} path
     */
    path:'',    
    /**
     * @cfg {String} urlForLoad
     */
    urlForLoad:'',   
    /**
     * @cfg {Object} paramsForLoad
     */
    paramsForLoad:{},
    /**
     * @cfg {String} urlForSubmit
     */
    urlForSubmit:'',   
    /**
     * @cfg {Object} paramsForSubmit
     */
    paramsForSubmit:{},
    /**
     * @cfg {Boolean} loadOnExpand
     * If true, loading will be triggered by first-time expanding.
     */
    loadOnExpand:false,
    /**
     * Data converter which is invoked against data got from remote server before loading it into Panel
     */
    translateForLoad:function(data){return data},
    /**
     * Data converter which is invoked against data before submitting it to remote server
     */
    translateForSubmit:function(data){return data},

    /**
     * @property
     */
    loadedData:{},
    
    /**
     * @property
     */
    submitResponseData:{},

    /**
     * @private
     */
    isReflective:true,
    loaded:false,

    initComponent:function(){    	
    	if(this.loadOnExpand){	
    		this.collapsed=true;
    		this.collapsible=true;
    		this.on('expand',this.load);
    	}	
    	this.callParent();
    },
    
    /**
     * @return all children that are not "Reflective" components
     */
    nonReflectiveChildren:function(selector){
		var iterator='>{isReflective==null}',result=this.query(selector);
		while(this.query(iterator).length>0){
			result=result.concat(this.query(iterator+' '+selector));
			iterator+=' >{isReflective==null}';
		}
		return result;
    },
    
    /**
     * @return form fields
     */
    getFields:function(){
		return this.nonReflectiveChildren('>[isFormField]');
    },
    
    /**
     * @return direct reflective child
     */
    getChildReflectives:function(){
		return this.nonReflectiveChildren('>[isReflective]');
    },
    
    /**
     * Build child item with given data. Can be overridden by subclasses
     */
    buildItem:function(item,data,path){
		if(item.root!=this.root)
			return;
		if(item.loadOnExpand){
			for(var key in item.paramsForLoad)
				if(item.paramsForLoad[key]==null)
					item.paramsForLoad[key]=data[key];
		}
		else
			item.buildFrom(data[path]);
    },

    /**
     * Build panel from given data. Can be overridden by subclasses
     */
    buildFrom:function(data){
		this.loadedData=this.translateForLoad(data);
    	if(!this.loadedData)	// nulll or not defined
			return;
		
		var fields=this.getFields();
		for(var i=0;i<fields.length;i++){
			var value=this.loadedData[fields[i].name];
			if(fields[i].isRadio==true){
				if(typeof value==="boolean")
					fields[i].setValue(value);
				else{
					if(fields[i].inputValue==value)
						fields[i].setValue(true);
					else
						fields[i].setValue(false);
				}
			}else
				fields[i].setValue(value);
		}

		var reflectives=this.getChildReflectives();
		for(i=0;i<reflectives.length;i++)
			this.buildItem(reflectives[i],this.loadedData,reflectives[i].path);
		
		this.loaded=true;
    },
    
	/**
     * Get data from a remote server by sending an AJAX request and then load hierarchy of "Reflective" components recursively. 
     * 
     * Should not  be overridden by subclasses
     * 
     * @param {Object} options An object which may contain the following properties:
     *
     * (The options object may also contain any other property which might be needed to perform
     * postprocessing in a callback because it is passed to callback functions.)
     *
     * @param {String/Function} options.url The URL to which to send the request, or a function
     * to call which returns a URL string. The scope of the function is specified by the `scope` option.
     * Defaults to the configured `url`.
     *
     * @param {Object/String/Function} options.params An object containing properties which are
     * used as parameters to the request, a url encoded string or a function to call to get either. The scope
     * of the function is specified by the `scope` option.
     *
     * @param {String} options.method The HTTP method to use
     * for the request. Defaults to the configured method, or if no method was configured,
     * "GET" if no parameters are being sent, and "POST" if parameters are being sent.  Note that
     * the method name is case-sensitive and should be all caps.
     *
     * @param {Function} options.callback The function to be called upon receipt of the HTTP response.
     * The callback is called regardless of success or failure and is passed the following parameters:
     * @param {Object} options.callback.options The parameter to the request call.
     * @param {Boolean} options.callback.success True if the request succeeded.
     * @param {Object} options.callback.response The XMLHttpRequest object containing the response data.
     * See [www.w3.org/TR/XMLHttpRequest/](http://www.w3.org/TR/XMLHttpRequest/) for details about
     * accessing elements of the response.
     *
     * @param {Function} options.success The function to be called upon success of the request.
     * The callback is passed the following parameters:
     * @param {Object} options.success.response The XMLHttpRequest object containing the response data.
     * @param {Object} options.success.options The parameter to the request call.
     *
     * @param {Function} options.failure The function to be called upon failure of the request.
     * The callback is passed the following parameters:
     * @param {Object} options.failure.response The XMLHttpRequest object containing the response data.
     * @param {Object} options.failure.options The parameter to the request call.
     *
     * @param {Object} options.scope The scope in which to execute the callbacks: The "this" object for
     * the callback function. If the `url`, or `params` options were specified as functions from which to
     * draw values, then this also serves as the scope for those function calls. Defaults to the browser
     * window.
     *
     * @param {Number} options.timeout The timeout in milliseconds to be used for this request.
     * Defaults to 30 seconds.
     *
     * @param {Boolean} options.force Force to load even if loaded.
     * 
     * @param {String} options.waitMsg Message to show on a standard message box while waiting for response
     * 
     */
    load:function(options){
    	if(this.loaded && !options.force)
    		return;
    	var parent=this.up('[isReflective]');
    	if(parent && parent.loaded==false && parent.root==this.root)
    		return;	//	Parent panel must be loaded first
    	var opt={};
    	Ext.apply(opt,options);
		opt.scope=this;
    	if(!opt.url)
    		opt.url=this.urlForLoad;
    	if(!opt.params)
    		opt.params=this.paramsForLoad;
    	var scope=(options&&options.scope)?options.scope:opt.scope;
    	opt.success=function(response,opts){
    		try{
    			var data=Ext.decode(response.responseText);
    			this.buildFrom(data);
    		}finally{
    			if(options&&options.waitMsg)
    				Ext.Msg.close();
    		}	
    		if(options&&options.success instanceof Function)
    			options.success.call(scope,response,opts);
    	};
    	opt.failure=function(response,opts){
			if(options&&options.waitMsg)
				Ext.Msg.close();
			if(options&&options.failure instanceof Function)
				options.failure.call(scope,response,opts);
    	};
    	Ext.Ajax.request(opt);
    	if(options&&options.waitMsg)
    		Ext.Msg.wait(options.waitMsg);
    },
    
    /**
     * Clear all data loaded and then set loaded to false.Can be overridden by subclasses
     */
    reset:function(){
		var fields=this.getFields();
		for(var i=0;i<fields.length;i++)
			fields[i].reset();
		var reflectives=this.getChildReflectives();
		for(i=0;i<reflectives.length;i++)
			reflectives[i].reset();
		if(this.loadOnExpand)
			this.collapse();
    	this.loaded=false;
    },
    
    
    /**
     * Get loaded data
     */
    getLoadedData:function(){
		return this.loadedData;
    },

    /**
     * Get data for submit. Can be overridden by subclasses
     */
    getSubmitData:function(){
		var data={};
		var fields=this.getFields();
		var radioGroups={};
		for(var i=0;i<fields.length;i++){
			if(fields[i].submitValue===false)	// skip field configured as "don't submit"
				continue;
			if(fields[i].isRadio==true){	// group radio boxes by name
				if(radioGroups[fields[i].name]==undefined)
					radioGroups[fields[i].name]={count:1,checked:fields[i].getValue(),submitValue:fields[i].getSubmitValue()};
				else{ 
					radioGroups[fields[i].name].count+=1;	//	Increment count of items
					if(fields[i].getValue()==true)
						radioGroups[fields[i].name].submitValue=fields[i].getSubmitValue();
				}
			}else
				data[fields[i].name]=fields[i].getValue();
		}
		for(var name in radioGroups){				// radio group process
			if(radioGroups[name].count>1)	//	Radio group
				data[name]=radioGroups[name].submitValue;
			else	//	Single radio box
				data[name]=radioGroups[name].checked;
		}
		var reflectives=this.getChildReflectives();
		for(i=0;i<reflectives.length;i++)
		{
			data[reflectives[i].path]=reflectives[i].getSubmitData();
		}
		return this.translateForSubmit(data);
    },

	/**
     * Submit data to remote server by sending an AJAX request.Should not  be overridden by subclasses
     * 
     * @param {Object} options An object which may contain the following properties:
     *
     * (The options object may also contain any other property which might be needed to perform
     * postprocessing in a callback because it is passed to callback functions.)
     *
     * @param {String/Function} options.url The URL to which to send the request, or a function
     * to call which returns a URL string. The scope of the function is specified by the `scope` option.
     * Defaults to the configured `url`.
     *
     * @param {Object/String/Function} options.params An object containing properties which are
     * used as parameters to the request, a url encoded string or a function to call to get either. The scope
     * of the function is specified by the `scope` option.
     *
     * @param {String} options.method The HTTP method to use
     * for the request. Defaults to the configured method, or if no method was configured,
     * "GET" if no parameters are being sent, and "POST" if parameters are being sent.  Note that
     * the method name is case-sensitive and should be all caps.
     *
     * @param {Function} options.callback The function to be called upon receipt of the HTTP response.
     * The callback is called regardless of success or failure and is passed the following parameters:
     * @param {Object} options.callback.options The parameter to the request call.
     * @param {Boolean} options.callback.success True if the request succeeded.
     * @param {Object} options.callback.response The XMLHttpRequest object containing the response data.
     * See [www.w3.org/TR/XMLHttpRequest/](http://www.w3.org/TR/XMLHttpRequest/) for details about
     * accessing elements of the response.
     *
     * @param {Function} options.success The function to be called upon success of the request.
     * The callback is passed the following parameters:
     * @param {Object} options.success.response The XMLHttpRequest object containing the response data.
     * @param {Object} options.success.options The parameter to the request call.
     *
     * @param {Function} options.failure The function to be called upon failure of the request.
     * The callback is passed the following parameters:
     * @param {Object} options.failure.response The XMLHttpRequest object containing the response data.
     * @param {Object} options.failure.options The parameter to the request call.
     *
     * @param {Object} options.scope The scope in which to execute the callbacks: The "this" object for
     * the callback function. If the `url`, or `params` options were specified as functions from which to
     * draw values, then this also serves as the scope for those function calls. Defaults to the browser
     * window.
     *
     * @param {Number} options.timeout The timeout in milliseconds to be used for this request.
     * Defaults to 30 seconds.
     *
     * @param {String} options.waitMsg Message to show on a standard message box while waiting for response
     * 
     */
    submit:function(options){
		if(this.path!='')
			return;	
    	var opt={};
    	Ext.apply(opt,options);
		opt.scope=this;
    	if(!opt.url)
    		opt.url=this.urlForSubmit;
    	if(!opt.params)
    		opt.params=this.paramsForSubmit;
    	opt.jsonData=this.getSubmitData();	//	prepare data for submit
    	var scope=(options&&options.scope)?options.scope:opt.scope;
    	opt.success=function(response,opts){
			if(options&&options.waitMsg)	//	close wait message box
				Ext.Msg.close();
			this.submitResponseData=Ext.decode(response.responseText);
			if(options&&options.success instanceof Function)
				options.success.call(scope,response,opts);
    	};
    	opt.failure=function(response,opts){
    		if(options&&options.waitMsg)	//	close wait message box
    			Ext.Msg.close();
    		if(options&&options.failure  instanceof Function)
    			options.failure.call(scope,response,opts);
    	};
    	Ext.Ajax.request(opt);
    	if(options&&options.waitMsg)	//	show message and wait
    		Ext.Msg.wait(options.waitMsg);
    }

});
