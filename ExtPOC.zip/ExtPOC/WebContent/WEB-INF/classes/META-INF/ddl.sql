create table app.Customer(
	customerId  varchar(10) primary key,
	firstName varchar(10),
	lastName varchar(50),
	homePhone varchar(50),
	cellPhone varchar(20),
	addr1 varchar(50),
	addr2 varchar(50),
	city varchar(50),
	postalCode varchar(10),
	email varchar(50),
	password varchar(10));
	
create table app.Product(
	productId varchar(10) primary key,
	name varchar(50),
	price double,
	supplier varchar(50));

create table app.CustOrder(
	orderId varchar(10) primary key,
	placedDate Date,
	price double,
	status char(1),
	comments varchar(100),	
	customer char(10)
);

create table app.OrderProduct(
	orderProductId varchar(10) primary key,
	orderId varchar(10),
	productId varchar(10),
	quantity int,
	comments varchar(100));
	