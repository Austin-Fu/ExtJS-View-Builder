package entities;

import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Entity(name="CustOrder")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Order implements Serializable {
	@Id
	private String orderId;

	private Date placedDate;

	private BigDecimal price;

	private String status;

	private String comments;

	@ManyToOne
	@JoinColumn(name="customer")
	@JsonIgnore
	private Customer customer;

	@OneToMany(mappedBy="order",fetch=EAGER)
	private Set<OrderProduct> productsCollection;

	private static final long serialVersionUID = 1L;

	public Order() {
		super();
	}

	public String getOrderId() {
		return this.orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Date getPlacedDate() {
		return this.placedDate;
	}

	public void setPlacedDate(Date placedDate) {
		this.placedDate = placedDate;
	}

	public BigDecimal getPrice() {
		return this.price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getComments() {
		return this.comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	@JsonIgnore
	public Customer getCustomerId() {
		return this.customer;
	}

	@JsonIgnore
	public void setCustomerId(Customer customerId) {
		this.customer = customerId;
	}

	public Set<OrderProduct> getProductsCollection() {
		return this.productsCollection;
	}

	public void setProductsCollection(Set<OrderProduct> productsCollection) {
		this.productsCollection = productsCollection;
	}

}
