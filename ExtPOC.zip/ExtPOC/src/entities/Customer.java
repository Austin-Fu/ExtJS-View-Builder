package entities;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import static javax.persistence.FetchType.EAGER;
import javax.persistence.NamedQuery;
import javax.persistence.NamedQueries;

@Entity
@NamedQueries({@NamedQuery(name="getCustomer", query = "SELECT c FROM Customer c"),@NamedQuery(name="getCustomersOrdered", query = "SELECT c FROM Customer c ORDER BY c.customerId")})
public class Customer implements Serializable {
	@Id
	private String customerId;

	private String firstName;

	private String lastName;

	private String homePhone;

	private String cellPhone;

	private String addr1;

	private String addr2;

	private String city;

	private String postalCode;

	private String email;

	private String password;

	@OneToMany(mappedBy="customer", fetch = EAGER)
	private Set<Order> ordersCollection;

	private static final long serialVersionUID = 1L;

	public Customer() {
		super();
	}

	public String getCustomerId() {
		return this.customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getHomePhone() {
		return this.homePhone;
	}

	public void setHomePhone(String homePhone) {
		this.homePhone = homePhone;
	}

	public String getCellPhone() {
		return this.cellPhone;
	}

	public void setCellPhone(String cellPhone) {
		this.cellPhone = cellPhone;
	}

	public String getAddr1() {
		return this.addr1;
	}

	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}

	public String getAddr2() {
		return this.addr2;
	}

	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPostalCode() {
		return this.postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Set<Order> getOrdersCollection() {
		return this.ordersCollection;
	}

	public void setOrdersCollection(Set<Order> ordersCollection) {
		this.ordersCollection = ordersCollection;
	}

}
