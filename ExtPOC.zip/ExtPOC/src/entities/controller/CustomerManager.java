/**
 * 
 */
package entities.controller;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import entities.Customer;
import entities.Order;
import entities.OrderProduct;
import entities.Product;

import java.lang.String;
import java.util.List;
import javax.persistence.Query;

/**
 * @author afu02
 *
 */
@SuppressWarnings("unchecked")
public class CustomerManager {

	public CustomerManager() {
	
	}

	private EntityManager getEntityManager() {
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("test");
		return emf.createEntityManager();
	}

	//@Action(Action.ACTION_TYPE.CREATE)
	public String createCustomer(Customer customer) throws Exception {
		EntityManager em = getEntityManager();
		try {
			em.getTransaction().begin();
			em.persist(customer);
			em.getTransaction().commit();
		} catch (Exception ex) {
			try {
				if (em.getTransaction().isActive()) {
					em.getTransaction().rollback();
				}
			} catch (Exception e) {
				ex.printStackTrace();
				throw e;
			}
			throw ex;
		} finally {
			em.close();
		}
		return "";
	}


	//@Action(Action.ACTION_TYPE.UPDATE)
	public String updateCustomer(Customer customer) throws Exception {
		EntityManager em = getEntityManager();
		try {
			em.getTransaction().begin();
			customer = em.merge(customer);
			em.getTransaction().commit();
		} catch (Exception ex) {
			try {
				if (em.getTransaction().isActive()) {
					em.getTransaction().rollback();
				}
			} catch (Exception e) {
				ex.printStackTrace();
				throw e;
			}
			throw ex;
		} finally {
			em.close();
		}
		return "";
	}

	//@Action(Action.ACTION_TYPE.FIND)
	public Customer findCustomerById(String customerId) {
		Customer customers = null;
		EntityManager em = getEntityManager();
		try {
			customers = (Customer) em.find(Customer.class, customerId);
		} finally {
			em.close();
		}
		return customers;
	}

	public Order findOrderById(String orderId) {
		Order order = null;
		EntityManager em = getEntityManager();
		try {
			order = (Order) em.find(Order.class, orderId);
		} finally {
			em.close();
		}
		return order;
	}

	public Product findProductById(String productId) {
		Product product = null;
		EntityManager em = getEntityManager();
		try {
			product = (Product) em.find(Product.class, productId);
		} finally {
			em.close();
		}
		return product;
	}
	
	public Order placeOrder(Order order) throws Exception {
		EntityManager em = getEntityManager();
		try {
			em.getTransaction().begin();
			em.persist(order);
			em.getTransaction().commit();
			return order;
		} catch (Exception ex) {
			try {
				if (em.getTransaction().isActive()) {
					em.getTransaction().rollback();
				}
			} catch (Exception e) {
			}
			throw ex;
		} finally {
			em.close();
		}
	}	

	public OrderProduct addOderProduct(OrderProduct orderProduct) throws Exception {
		EntityManager em = getEntityManager();
		try {
			em.getTransaction().begin();
			em.persist(orderProduct);
			em.getTransaction().commit();
			return orderProduct;
		} catch (Exception ex) {
			try {
				if (em.getTransaction().isActive()) {
					em.getTransaction().rollback();
				}
			} catch (Exception e) {
			}
			throw ex;
		} finally {
			em.close();
		}
	}	
	
	public void removeOrder(Order order) throws Exception {
		EntityManager em = getEntityManager();
		try {
			em.getTransaction().begin();
			em.remove(em.find(Order.class,order.getOrderId()));
			em.getTransaction().commit();
		} catch (Exception ex) {
			try {
				if (em.getTransaction().isActive()) {
					em.getTransaction().rollback();
				}
			} catch (Exception e) {
			}
			throw ex;
		} finally {
			em.close();
		}
	}	

	public void removeOderProduct(OrderProduct orderProduct) throws Exception {
		EntityManager em = getEntityManager();
		try {
			em.getTransaction().begin();
			em.remove(em.find(OrderProduct.class, orderProduct.getOrderProductId()));
			em.getTransaction().commit();
		} catch (Exception ex) {
			try {
				if (em.getTransaction().isActive()) {
					em.getTransaction().rollback();
				}
			} catch (Exception e) {
			}
			throw ex;
		} finally {
			em.close();
		}
	}	
}