/**
 * 
 */
package entities.controller;

//import com.ibm.jpa.web.JPAManager;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
//import com.ibm.jpa.web.NamedQueryTarget;
//import com.ibm.jpa.web.Action;
import javax.persistence.Persistence;
import entities.Customers;
import java.lang.String;
import java.util.List;
import javax.persistence.Query;

/**
 * @author afu02
 *
 */
//@JPAManager(targetEntity=entities.Customers.class)
@SuppressWarnings("unchecked")
public class CustomersManager {

	public CustomersManager() {
	
	}

	private EntityManager getEntityManager() {
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("test");
		return emf.createEntityManager();
	}

	//@Action(Action.ACTION_TYPE.CREATE)
	public String createCustomers(Customers customers) throws Exception {
		EntityManager em = getEntityManager();
		try {
			em.getTransaction().begin();
			em.persist(customers);
			em.getTransaction().commit();
		} catch (Exception ex) {
			try {
				if (em.getTransaction().isActive()) {
					em.getTransaction().rollback();
				}
			} catch (Exception e) {
				ex.printStackTrace();
				throw e;
			}
			throw ex;
		} finally {
			em.close();
		}
		return "";
	}

	//@Action(Action.ACTION_TYPE.DELETE)
	public String deleteCustomers(Customers customers) throws Exception {
		EntityManager em = getEntityManager();
		try {
			em.getTransaction().begin();
			customers = em.merge(customers);
			em.remove(customers);
			em.getTransaction().commit();
		} catch (Exception ex) {
			try {
				if (em.getTransaction().isActive()) {
					em.getTransaction().rollback();
				}
			} catch (Exception e) {
				ex.printStackTrace();
				throw e;
			}
			throw ex;
		} finally {
			em.close();
		}
		return "";
	}

	//@Action(Action.ACTION_TYPE.UPDATE)
	public String updateCustomers(Customers customers) throws Exception {
		EntityManager em = getEntityManager();
		try {
			em.getTransaction().begin();
			customers = em.merge(customers);
			em.getTransaction().commit();
		} catch (Exception ex) {
			try {
				if (em.getTransaction().isActive()) {
					em.getTransaction().rollback();
				}
			} catch (Exception e) {
				ex.printStackTrace();
				throw e;
			}
			throw ex;
		} finally {
			em.close();
		}
		return "";
	}

	//@Action(Action.ACTION_TYPE.FIND)
	public Customers findCustomersByCustomerId(String customerId) {
		Customers customers = null;
		EntityManager em = getEntityManager();
		try {
			customers = (Customers) em.find(Customers.class, customerId);
		} finally {
			em.close();
		}
		return customers;
	}

	//@Action(Action.ACTION_TYPE.NEW)
	public Customers getNewCustomers() {
		Customers customers = new Customers();
		return customers;
	}

	////@NamedQueryTarget("getCustomers")
	public List<Customers> getCustomers() {
		EntityManager em = getEntityManager();
		List<Customers> results = null;
		try {
			Query query = em.createNamedQuery("getCustomers");
			results = (List<Customers>) query.getResultList();
		} finally {
			em.close();
		}
		return results;
	}

	////@NamedQueryTarget("getCustomersOrdered")
	public List<Customers> getCustomersOrdered() {
		EntityManager em = getEntityManager();
		List<Customers> results = null;
		try {
			Query query = em.createNamedQuery("getCustomersOrdered");
			results = (List<Customers>) query.getResultList();
		} finally {
			em.close();
		}
		return results;
	}

	////@NamedQueryTarget("getCustomersByFirstName")
	public List<Customers> getCustomersByFirstName(String firstName) {
		EntityManager em = getEntityManager();
		List<Customers> results = null;
		try {
			Query query = em.createNamedQuery("getCustomersByFirstName");
			query.setParameter("firstName", firstName);
			results = (List<Customers>) query.getResultList();
		} finally {
			em.close();
		}
		return results;
	}

	////@NamedQueryTarget("getCustomersByLastName")
	public List<Customers> getCustomersByLastName(String lastName) {
		EntityManager em = getEntityManager();
		List<Customers> results = null;
		try {
			Query query = em.createNamedQuery("getCustomersByLastName");
			query.setParameter("lastName", lastName);
			results = (List<Customers>) query.getResultList();
		} finally {
			em.close();
		}
		return results;
	}

	////@NamedQueryTarget("getCustomersByHomePhone")
	public List<Customers> getCustomersByHomePhone(String homePhone) {
		EntityManager em = getEntityManager();
		List<Customers> results = null;
		try {
			Query query = em.createNamedQuery("getCustomersByHomePhone");
			query.setParameter("homePhone", homePhone);
			results = (List<Customers>) query.getResultList();
		} finally {
			em.close();
		}
		return results;
	}

	////@NamedQueryTarget("getCustomersByCellPhone")
	public List<Customers> getCustomersByCellPhone(String cellPhone) {
		EntityManager em = getEntityManager();
		List<Customers> results = null;
		try {
			Query query = em.createNamedQuery("getCustomersByCellPhone");
			query.setParameter("cellPhone", cellPhone);
			results = (List<Customers>) query.getResultList();
		} finally {
			em.close();
		}
		return results;
	}

	//@NamedQueryTarget("getCustomersByAddr1")
	public List<Customers> getCustomersByAddr1(String addr1) {
		EntityManager em = getEntityManager();
		List<Customers> results = null;
		try {
			Query query = em.createNamedQuery("getCustomersByAddr1");
			query.setParameter("addr1", addr1);
			results = (List<Customers>) query.getResultList();
		} finally {
			em.close();
		}
		return results;
	}

	//@NamedQueryTarget("getCustomersByAddr2")
	public List<Customers> getCustomersByAddr2(String addr2) {
		EntityManager em = getEntityManager();
		List<Customers> results = null;
		try {
			Query query = em.createNamedQuery("getCustomersByAddr2");
			query.setParameter("addr2", addr2);
			results = (List<Customers>) query.getResultList();
		} finally {
			em.close();
		}
		return results;
	}

	//@NamedQueryTarget("getCustomersByCity")
	public List<Customers> getCustomersByCity(String city) {
		EntityManager em = getEntityManager();
		List<Customers> results = null;
		try {
			Query query = em.createNamedQuery("getCustomersByCity");
			query.setParameter("city", city);
			results = (List<Customers>) query.getResultList();
		} finally {
			em.close();
		}
		return results;
	}

	//@NamedQueryTarget("getCustomersByPostalCode")
	public List<Customers> getCustomersByPostalCode(String postalCode) {
		EntityManager em = getEntityManager();
		List<Customers> results = null;
		try {
			Query query = em.createNamedQuery("getCustomersByPostalCode");
			query.setParameter("postalCode", postalCode);
			results = (List<Customers>) query.getResultList();
		} finally {
			em.close();
		}
		return results;
	}

	//@NamedQueryTarget("getCustomersByEmail")
	public List<Customers> getCustomersByEmail(String email) {
		EntityManager em = getEntityManager();
		List<Customers> results = null;
		try {
			Query query = em.createNamedQuery("getCustomersByEmail");
			query.setParameter("email", email);
			results = (List<Customers>) query.getResultList();
		} finally {
			em.close();
		}
		return results;
	}

	//@NamedQueryTarget("getCustomersByPassword")
	public List<Customers> getCustomersByPassword(String password) {
		EntityManager em = getEntityManager();
		List<Customers> results = null;
		try {
			Query query = em.createNamedQuery("getCustomersByPassword");
			query.setParameter("password", password);
			results = (List<Customers>) query.getResultList();
		} finally {
			em.close();
		}
		return results;
	} 
 }