package servlet.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import entities.Customer;
import entities.Order;
import entities.OrderProduct;
import entities.controller.CustomerManager;
 
@Controller
public class ManageCustomerAjaxController extends BaseAjaxController {

	private CustomerManager em=new CustomerManager();
	
	
	@RequestMapping(value="loadCustomer",produces="application/json")
	public @ResponseBody Customer loadCustomer(@RequestParam String customerId,@RequestParam String password) throws Exception {
		Customer customer=em.findCustomerById(customerId);
		if(password.equals(customer.getPassword())){
			return customer;
		}
		else
			return null;
	}

	@RequestMapping(value="updateCustomer",consumes="application/json",produces="application/json")
	public @ResponseBody Customer updateCustomer(@RequestBody Customer customer){
		try {
			em.updateCustomer(customer);
			return customer;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@RequestMapping(value="placeOrder",consumes="application/json",produces="application/json")
	public @ResponseBody Order placeOrder(@RequestParam String customerId,@RequestBody Order order){
		try {
			order.setCustomerId(em.findCustomerById(customerId));
			em.placeOrder(order);
			return order;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	@RequestMapping(value="addOrderProduct",consumes="application/json",produces="application/json")
	public @ResponseBody OrderProduct addOrderPrdouct(@RequestParam String orderId,@RequestParam String productId,@RequestBody OrderProduct orderProduct){
		try {
			orderProduct.setOrder(em.findOrderById(orderId));
			orderProduct.setProduct(em.findProductById(productId));
			em.addOderProduct(orderProduct);
			return orderProduct;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value="removeOrder",consumes="application/json",produces="application/json")
	public  @ResponseBody Order removeOrder(@RequestBody Order order){
		try {
			em.removeOrder(order);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value="removeOrderProduct",consumes="application/json",produces="application/json")
	public @ResponseBody OrderProduct removeOrderPrdouct(@RequestBody OrderProduct orderProduct){
		try {
			em.removeOderProduct(orderProduct);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}