package servlet.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConversionException;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
 
@Controller
public class BaseAjaxController {

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String, String>> methodArgumentNotValidExceptionHandler(MethodArgumentNotValidException ex) {
		System.out.println("methodArgumentNotValidExceptionHandler(), ex: " + ex);
		Map<String, String> failureMessages = new HashMap<String, String>();
		BindingResult bindingResult = ex.getBindingResult();
		for (FieldError fe : bindingResult.getFieldErrors()) {
			failureMessages.put(fe.getField(), fe.getDefaultMessage());
		}
		ResponseEntity<Map<String, String>> re = new ResponseEntity<Map<String, String>>(failureMessages, HttpStatus.BAD_REQUEST);
		return re;
	}

	@ExceptionHandler(HttpMessageConversionException.class)
	public ResponseEntity<Map<String, String>> httpMessageConversionExceptionHandler(HttpMessageConversionException ex) {
		System.out.println("httpMessageConversionExceptionHandler(), ex: " + ex);
		Map<String, String> failureMessages = new HashMap<String, String>();
		String message = ex.getMostSpecificCause().getMessage();
		failureMessages.put("error", message);
		ResponseEntity<Map<String, String>> re = new ResponseEntity<Map<String, String>>(failureMessages, HttpStatus.BAD_REQUEST);
		return re;
	}
}